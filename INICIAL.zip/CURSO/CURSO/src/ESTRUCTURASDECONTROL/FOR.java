package ESTRUCTURASDECONTROL;

public class FOR {
    public static void main(String[] args) {
        for(int i= 0; i<10;i++){
            System.out.println(i);
        }
        for(int i= 10; i>0;i--){
            System.out.println(i);
        }
        for(int i=0;i<=50;i+=5){
            System.out.println(i);
        }
    }
}
