package EJERCICIOS.EJERCICIO17;

public class ProgramaPrincipal {
    public static void main(String[] args) {
        // Crear instancias de Usuario y Administrador
        Usuario usuario = new Usuario("usuario123", "pass123");
        Administrador administrador = new Administrador("admin", "adminPass");

        // Demostrar autenticación
        System.out.println("Autenticación de Usuario: " + usuario.autenticar("usuario123", "pass123"));
        System.out.println("Autenticación de Administrador: " + administrador.autenticar("admin", "adminPass"));
    }
}