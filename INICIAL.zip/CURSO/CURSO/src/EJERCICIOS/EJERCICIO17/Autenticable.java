package EJERCICIOS.EJERCICIO17;

// Definición de la interfaz Autenticable
interface Autenticable {
    boolean autenticar(String nombreUsuario, String contraseña);
}
