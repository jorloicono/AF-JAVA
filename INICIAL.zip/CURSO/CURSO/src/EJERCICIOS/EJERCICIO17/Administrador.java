package EJERCICIOS.EJERCICIO17;

class Administrador implements Autenticable {
    private String nombreUsuario;
    private String contraseña;

    public Administrador(String nombreUsuario, String contraseña) {
        this.nombreUsuario = nombreUsuario;
        this.contraseña = contraseña;
    }

    // Implementación del método autenticar para Administrador
    @Override
    public boolean autenticar(String nombreUsuario, String contraseña) {
        // Aquí podrías agregar lógica específica para la autenticación de un administrador
        return this.nombreUsuario.equals(nombreUsuario) && this.contraseña.equals(contraseña);
    }
}
