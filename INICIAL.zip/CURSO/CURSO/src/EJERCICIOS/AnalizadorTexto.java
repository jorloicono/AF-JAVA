package EJERCICIOS;

import java.util.regex.*;
import java.util.*;

public class AnalizadorTexto {

    public static void extraerCorreos(String texto) {
        String regex = "[a-zA-Z0-9_+&*-]+(?:\\.[a-zA-Z0-9_+&*-]+)*@[a-zA-Z0-9-]+(?:\\.[a-zA-Z0-9-]+)*";
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(texto);
        System.out.println("Correos electrónicos encontrados:");
        while (matcher.find()) {
            System.out.println(matcher.group());
        }
    }

    public static void extraerURLs(String texto) {
        String regex = "(https?://[\\w.-]+(?:/[^\\s]*)?)";
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(texto);
        System.out.println("URLs encontradas:");
        while (matcher.find()) {
            System.out.println(matcher.group());
        }
    }

    public static void extraerFechas(String texto) {
        String regex = "(0[1-9]|[12][0-9]|3[01])/(0[1-9]|1[0-2])/([0-9]{4})";
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(texto);
        System.out.println("Fechas válidas encontradas:");
        while (matcher.find()) {
            System.out.println(matcher.group());
        }
    }

    public static void buscarNIF(String texto) {
        String regex = "\\d{8}[A-HJ-NP-TV-Z]";
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(texto);
        if (matcher.find()) {
            System.out.println("NIF válido encontrado: " + matcher.group());
        } else {
            System.out.println("No se encontró ningún NIF válido.");
        }
    }

    public static void contarTelefonos(String texto) {
        String regex = "\\+34-\\d{3}-\\d{3}-\\d{3}";
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(texto);
        int contador = 0;
        while (matcher.find()) {
            contador++;
        }
        System.out.println("Número de teléfonos válidos encontrados: " + contador);
    }

    public static void main(String[] args) {
        String texto = """
                Puedes escribir a info@empresa.com o contactar con juan.gomez@otro.org. También puedes visitar http://www.empresa.com o https://otro.org/contacto. 
                Recuerda que la próxima reunión será el 15/04/2024. La anterior fue el 1/1/2023. El NIF del cliente es 45612378X. Su teléfono es +34-612-345-678.
                """;

        extraerCorreos(texto);
        extraerURLs(texto);
        extraerFechas(texto);
        buscarNIF(texto);
        contarTelefonos(texto);
    }
}

