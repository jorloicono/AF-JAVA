package EJERCICIOS;

import java.util.InputMismatchException;
import java.util.Scanner;

public class EJERCICIO24 {

    // Método estático para calcular el logaritmo neperiano
    public static double calcularLogaritmo(double valor) throws ArithmeticException {
        if (valor <= 0) {
            throw new ArithmeticException("El valor debe ser positivo para calcular el logaritmo neperiano");
        }
        return Math.log(valor);
    }

    // Método estático para calcular la raíz cuadrada
    public static double calcularRaizCuadrada(double valor) throws ArithmeticException {
        if (valor < 0) {
            throw new ArithmeticException("El valor no puede ser negativo para calcular la raíz cuadrada");
        }
        return Math.sqrt(valor);
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        try {
            // Ingresar un valor para calcular el logaritmo neperiano
            System.out.print("Ingrese un valor para calcular el logaritmo neperiano: ");
            double valorLogaritmo = scanner.nextDouble();
            double resultadoLogaritmo = calcularLogaritmo(valorLogaritmo);
            System.out.println("El logaritmo neperiano de " + valorLogaritmo + " es: " + resultadoLogaritmo);
        } catch (InputMismatchException e) {
            System.out.println("Error: Ingrese un valor numérico válido.");
        } catch (ArithmeticException e) {
            System.out.println("Error: " + e.getMessage());
        }

        try {
            // Ingresar un valor para calcular la raíz cuadrada
            System.out.print("Ingrese un valor para calcular la raíz cuadrada: ");
            double valorRaiz = scanner.nextDouble();
            double resultadoRaiz = calcularRaizCuadrada(valorRaiz);
            System.out.println("La raíz cuadrada de " + valorRaiz + " es: " + resultadoRaiz);
        } catch (InputMismatchException e) {
            System.out.println("Error: Ingrese un valor numérico válido.");
        } catch (ArithmeticException e) {
            System.out.println("Error: " + e.getMessage());
        } finally {
            scanner.close();
        }
    }
}
