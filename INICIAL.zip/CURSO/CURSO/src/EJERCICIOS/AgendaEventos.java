package EJERCICIOS;

public class AgendaEventos {

    public void gestionarEvento(String tipo) {
        if ("especial".equals(tipo)) {
            // Clase interna local EventoEspecial
            class EventoEspecial {
                String descripcion;

                // Constructor
                public EventoEspecial(String descripcion) {
                    this.descripcion = descripcion;
                }

                // Método mostrar
                public void mostrar() {
                    System.out.println("Descripción del evento: " + descripcion);
                }

                // Método urgente
                public boolean urgente() {
                    return descripcion.contains("urgente");
                }
            }

            // Crear un EventoEspecial y mostrar sus métodos
            EventoEspecial evento = new EventoEspecial("Reunión urgente con dirección");
            evento.mostrar();
            System.out.println("¿Es urgente? " + evento.urgente());

        } else if ("normal".equals(tipo)) {
            // Clase anónima que implementa Runnable
            Runnable eventoNormal = new Runnable() {
                @Override
                public void run() {
                    System.out.println("Ejecutando evento normal...");
                }
            };

            // Ejecutar el evento normal
            eventoNormal.run();
        }
    }

    public static void main(String[] args) {
        AgendaEventos agenda = new AgendaEventos();

        // Probar el caso "especial"
        System.out.println("Caso 1: Evento especial");
        agenda.gestionarEvento("especial");

        // Probar el caso "normal"
        System.out.println("\nCaso 2: Evento normal");
        agenda.gestionarEvento("normal");
    }
}

