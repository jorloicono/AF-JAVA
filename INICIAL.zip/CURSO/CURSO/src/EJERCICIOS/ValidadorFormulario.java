package EJERCICIOS;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class ValidadorFormulario {

    public static void validarNombreCompleto(String nombre) {
        String regex = "^[A-Za-záéíóúÁÉÍÓÚÑñ ]{5,50}$";
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(nombre);
        if (matcher.matches()) {
            System.out.println("Nombre completo válido");
        } else {
            System.out.println("Nombre completo no válido");
        }
    }

    public static void validarDNI(String dni) {
        String regex = "^[0-9]{8}[^IUO]$";
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(dni);
        if (matcher.matches()) {
            System.out.println("DNI válido");
        } else {
            System.out.println("DNI no válido");
        }
    }

    public static void validarEmail(String email) {
        String regex = "^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+$";
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(email);
        if (matcher.matches()) {
            System.out.println("Correo electrónico válido");
        } else {
            System.out.println("Correo electrónico no válido");
        }
    }

    public static void validarFechaNacimiento(String fecha) {
        String regex = "^(0[1-9]|[12][0-9]|3[01])/(0[1-9]|1[0-2])/([0-9]{4})$";
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(fecha);
        if (matcher.matches()) {
            System.out.println("Fecha de nacimiento válida");
        } else {
            System.out.println("Fecha de nacimiento no válida");
        }
    }

    public static void validarContraseña(String contrasena) {
        String regex = "^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)(?=.*[@$!%*?&])[A-Za-z\\d@$!%*?&]{8,}$";
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(contrasena);
        if (matcher.matches()) {
            System.out.println("Contraseña válida");
        } else {
            System.out.println("Contraseña no válida");
        }
    }

    public static void main(String[] args) {
        // Prueba con ejemplos
        validarNombreCompleto("Juan Pérez");
        validarDNI("12345678A");
        validarEmail("juan.perez@correo.com");
        validarFechaNacimiento("15/04/2024");
        validarContraseña("Contraseña123!");
    }
}

