package EJERCICIOS.EJERCICIO14;

import java.lang.Math;

// Clase base Figura
class Figura {
    // Métodos para calcular el área y el perímetro
    public double calcularArea() {
        return 0;
    }

    public double calcularPerimetro() {
        return 0;
    }
}
