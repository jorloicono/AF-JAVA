package EJERCICIOS;

public class EJERCICIO7 {
    public static void main(String[] args) {
        // Ejemplo de uso
        int totalCupones = 37;

        // Definir el valor de intercambio de cupones por barras de caramelo y chicles
        final int BARRA_POR_CUPON = 10;
        final int CHICLE_POR_CUPON = 3;

        // Calcular el número de barras de caramelo que se pueden obtener
        int barrasDeCaramelo = totalCupones / BARRA_POR_CUPON;

        // Calcular el número de cupones restantes después de obtener barras de caramelo
        int cuponesRestantes = totalCupones % BARRA_POR_CUPON;

        // Calcular el número de chicles que se pueden obtener con los cupones restantes
        int chicles = cuponesRestantes / CHICLE_POR_CUPON;

        // Calcular el número de cupones restantes después de obtener chicles
        cuponesRestantes %= CHICLE_POR_CUPON;

        // Almacenar los resultados en un array
        int[] resultado = {barrasDeCaramelo, chicles, cuponesRestantes};

        // Imprimir los resultados
        System.out.println("Barras de Caramelo: " + resultado[0]);
        System.out.println("Chicles: " + resultado[1]);
        System.out.println("Cupones Restantes: " + resultado[2]);
    }
}