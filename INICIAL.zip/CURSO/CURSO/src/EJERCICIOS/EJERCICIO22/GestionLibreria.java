package EJERCICIOS.EJERCICIO22;

public class GestionLibreria {
    public static void main(String[] args) {
        // Instanciar al menos dos libros y dos clientes
        Libro libro1 = new Libro("El Principito", "Antoine de Saint-Exupéry", 1943, 15.99);
        Libro libro2 = new Libro("Cien años de soledad", "Gabriel García Márquez", 1967, 20.50);

        Cliente cliente1 = new Cliente("Juan Pérez", "Calle A, Ciudad", "123456789");
        Cliente cliente2 = new Cliente("María Gómez", "Avenida B, Pueblo", "987654321");

        // Imprimir información inicial
        System.out.println("Información inicial:");
        System.out.println("Libro 1: " + libro1.getTitulo() + ", Precio: " + libro1.getPrecio());
        System.out.println("Libro 2: " + libro2.getTitulo() + ", Precio: " + libro2.getPrecio());
        System.out.println("Cliente 1: " + cliente1.getNombre() + ", Dirección: " + cliente1.getDireccion());
        System.out.println("Cliente 2: " + cliente2.getNombre() + ", Dirección: " + cliente2.getDireccion());

        // Cambiar el precio de uno de los libros
        libro1.setPrecio(18.99);

        // Imprimir nueva información del libro modificado
        System.out.println("\nInformación del libro modificado:");
        System.out.println("Libro 1: " + libro1.getTitulo() + ", Precio: " + libro1.getPrecio());

        // Cambiar la dirección de uno de los clientes
        cliente2.setDireccion("Calle C, Villa");

        // Imprimir nueva información del cliente modificado
        System.out.println("\nInformación del cliente modificado:");
        System.out.println("Cliente 2: " + cliente2.getNombre() + ", Dirección: " + cliente2.getDireccion());
    }
}
