package EJERCICIOS;


import java.util.Arrays;

    public class EJERCICIO32 {
        public static void main(String[] args) {
            // Array de números
            int[] numeros = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10};

            // Operaciones con Streams
            int resultado = Arrays.stream(numeros) // Crea un stream a partir del array
                    .filter(n -> n % 2 == 0) // Filtra los números pares
                    .map(n -> n * n) // Eleva al cuadrado cada número
                    .sum(); // Suma los cuadrados obtenidos

            System.out.println("Resultado: " + resultado);
        }
    }


