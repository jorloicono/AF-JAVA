package EJERCICIOS;
import java.util.Arrays;

public class EJERCICIO8 {

    public static void main(String[] args) {
        int[] arrayDePrueba = {1, 2, 3, 3, 9, 8, 7, 4, 6, 7, 0, 4, 5};

        // Ordenar el array para facilitar la identificación de duplicados
        Arrays.sort(arrayDePrueba);

        // Variable para almacenar los elementos duplicados
        int[] elementosDuplicados = new int[arrayDePrueba.length];
        int indiceDuplicados = 0;

        for (int i = 0; i < arrayDePrueba.length - 1; i++) {
            if (arrayDePrueba[i] == arrayDePrueba[i + 1]) {
                // Encontrado un duplicado
                elementosDuplicados[indiceDuplicados++] = arrayDePrueba[i];
            }
        }

        // Crear un nuevo array con solo los elementos duplicados (eliminando ceros no utilizados)
        int[] resultado = Arrays.copyOfRange(elementosDuplicados, 0, indiceDuplicados);

        // Imprimir los elementos duplicados
        System.out.println("Elementos Duplicados: " + Arrays.toString(resultado));
    }
}