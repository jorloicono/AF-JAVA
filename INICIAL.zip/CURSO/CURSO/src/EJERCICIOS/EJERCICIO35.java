package EJERCICIOS;
import java.io.*;

public class EJERCICIO35 {
        public static void main(String[] args) {
            File archivoSalida = new File("salida.txt");

            try (BufferedWriter escritor = new BufferedWriter(new FileWriter(archivoSalida))) {
                escritor.write("Este es un ejemplo de escritura");
                escritor.newLine();
                escritor.write("Usando BufferedWriter");
                escritor.newLine();
                escritor.write("En un fichero de texto");
                escritor.newLine(); // opcional, por si quieres una línea en blanco al final
            } catch (IOException e) {
                System.out.println("Error al escribir en el archivo: " + e.getMessage());
            }
        }
    }


