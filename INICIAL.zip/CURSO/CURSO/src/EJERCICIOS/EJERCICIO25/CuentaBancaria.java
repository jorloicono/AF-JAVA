package EJERCICIOS.EJERCICIO25;

import java.util.InputMismatchException;
import java.util.Scanner;

class CuentaBancaria {
    private double saldo;

    public CuentaBancaria(double saldoInicial) {
        this.saldo = saldoInicial;
    }

    public void realizarDeposito(double monto) {
        if (monto < 0) {
            throw new IllegalArgumentException("No se permiten depósitos negativos");
        }
        saldo += monto;
    }

    public void realizarRetiro(double monto) {
        if (monto < 0) {
            throw new IllegalArgumentException("No se permiten retiros negativos");
        }
        if (monto > saldo) {
            throw new IllegalArgumentException("Fondos insuficientes para realizar el retiro");
        }
        saldo -= monto;
    }

    public double getSaldo() {
        return saldo;
    }
}