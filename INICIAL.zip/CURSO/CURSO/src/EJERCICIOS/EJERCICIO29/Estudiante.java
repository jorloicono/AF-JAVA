package EJERCICIOS.EJERCICIO29;

import java.util.HashSet;
import java.util.Set;

public class Estudiante {
    private String nombre;
    private int numeroEstudiante;
    private Set<String> cursosInscritos;

    // Constructor
    public Estudiante(String nombre, int numeroEstudiante) {
        this.nombre = nombre;
        this.numeroEstudiante = numeroEstudiante;
        this.cursosInscritos = new HashSet<>();
    }

    // Método para agregar un curso
    public void agregarCurso(String curso) {
        cursosInscritos.add(curso);
    }

    // Método para eliminar un curso
    public void eliminarCurso(String curso) {
        cursosInscritos.remove(curso);
    }

    // Método para mostrar la lista de cursos
    public void mostrarCursos() {
        System.out.println("Cursos inscritos por " + nombre + ":");
        for (String curso : cursosInscritos) {
            System.out.println(curso);
        }
    }

    // Método para obtener el nombre del estudiante
    public String getNombre() {
        return nombre;
    }

    public static void main(String[] args) {
        // Ejemplo de uso
        Estudiante estudiante1 = new Estudiante("Juan Perez", 12345);

        estudiante1.agregarCurso("Matemáticas");
        estudiante1.agregarCurso("Historia");
        estudiante1.mostrarCursos();

        estudiante1.eliminarCurso("Historia");
        estudiante1.agregarCurso("Biología");
        estudiante1.mostrarCursos();
    }
}

