package EJERCICIOS.EJERCICIO12;

public class Rectangulo {
    private int base;
    private int altura;

    // Constructor con parámetros
    public Rectangulo(int base, int altura) {
        this.base = Math.abs(base);
        this.altura = Math.abs(altura);
    }

    // Constructor sin parámetros
    public Rectangulo() {
        this.base = 2;
        this.altura = 1;
    }

    // Método para verificar si el rectángulo es un cuadrado
    public boolean esCuadrado() {
        return base == altura;
    }

    // Método para calcular el área del rectángulo
    public int area() {
        return base * altura;
    }

    // Método para calcular el perímetro del rectángulo
    public int perimetro() {
        return 2 * (base + altura);
    }

    // Método para girar el rectángulo 90 grados
    public void gira() {
        int temp = base;
        base = altura;
        altura = temp;
    }

    // Método main para probar la clase
    public static void main(String[] args) {
        // Crear un rectángulo con valores proporcionados
        Rectangulo rectangulo1 = new Rectangulo(4, 3);

        // Mostrar propiedades del rectángulo
        System.out.println("Rectángulo 1:");
        System.out.println("Base: " + rectangulo1.base);
        System.out.println("Altura: " + rectangulo1.altura);
        System.out.println("Es cuadrado: " + rectangulo1.esCuadrado());
        System.out.println("Área: " + rectangulo1.area());
        System.out.println("Perímetro: " + rectangulo1.perimetro());

        // Girar el rectángulo y mostrar las nuevas propiedades
        rectangulo1.gira();
        System.out.println("\nDespués de girar:");
        System.out.println("Base: " + rectangulo1.base);
        System.out.println("Altura: " + rectangulo1.altura);

        // Crear un rectángulo con valores por defecto
        Rectangulo rectangulo2 = new Rectangulo();

        // Mostrar propiedades del segundo rectángulo
        System.out.println("\nRectángulo 2:");
        System.out.println("Base: " + rectangulo2.base);
        System.out.println("Altura: " + rectangulo2.altura);
        System.out.println("Es cuadrado: " + rectangulo2.esCuadrado());
        System.out.println("Área: " + rectangulo2.area());
        System.out.println("Perímetro: " + rectangulo2.perimetro());
    }
}

