package EJERCICIOS;

import java.io.*;

public class EJERCICIO34 {
        public static void main(String[] args) {
            File archivo = new File("entrada.txt");

            if (!archivo.exists()) {
                System.out.println("No se encontró entrada.txt");
                return;
            }

            try (BufferedReader lector = new BufferedReader(new FileReader(archivo))) {
                String linea;
                while ((linea = lector.readLine()) != null) {
                    System.out.println(linea);
                }
            } catch (IOException e) {
                System.out.println("Error al leer el archivo: " + e.getMessage());
            }
        }
    }

