package EJERCICIOS.EJERCICIO31;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class StreamExample {
    public static void main(String[] args) {
        // Crear una lista de personas
        List<Persona> personas = Arrays.asList(
                new Persona("Juan", 30, "Ciudad A"),
                new Persona("María", 22, "Ciudad B"),
                new Persona("Carlos", 28, "Ciudad C"),
                new Persona("Ana", 26, "Ciudad A")
        );

        // Filtrar personas con edad mayor a 25
        List<Persona> personasMayoresDe25 = personas.stream()
                .filter(persona -> persona.getEdad() > 25)
                .collect(Collectors.toList());

        // Transformar el resultado a una lista de cadenas con nombre y ciudad
        List<String> nombresYCiudades = personasMayoresDe25.stream()
                .map(persona -> persona.getNombre() + " - " + persona.getCiudad())
                .collect(Collectors.toList());

        // Imprimir resultados
        System.out.println("Personas mayores de 25: " + personasMayoresDe25);
        System.out.println("Nombres y ciudades de personas mayores de 25: " + nombresYCiudades);
    }
}
