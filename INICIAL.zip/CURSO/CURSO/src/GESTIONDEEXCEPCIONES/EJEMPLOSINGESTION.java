package GESTIONDEEXCEPCIONES;

public class EJEMPLOSINGESTION {
    public static void main(String[] args) {

        //Declaración de variables
        int num1 = 15;
        int num2 = 20;
        int num3 = 0;

        //Operación aritmética que divide por cero
        double operacion = (num1+num2)/num3;
        System.out.println("El resultado de la operación es: "+operacion);
    }
}

/*En este ejemplo podemos observar cómo se declaran tres variables y,
a continuación, se realiza una operación matemática cuyo resultado se guarda
en la variable “operación”. Desde el punto de vista sintáctico, el programa no
presenta ningún defecto en su construcción y el IDE que empleemos, de momento,
no detectará que el programa va a generar un error. Será durante su fase de
ejecución cuando el programa deje de funcionar, pues llegados a la línea donde
se realiza la operación, intentará realizar una división entre la suma de las
dos variables y num3, cuyo valor es cero. En este momento, el flujo del programa
se detendrá, mostrándonos por consola el siguiente mensaje
 */

