package GESTIONDEEXCEPCIONES;

import java.util.InputMismatchException;
import java.util.Scanner;

public class TRYCATCH2 {
    public static void main(String[] args) {
        int num;
        Scanner entrada = new Scanner(System.in);
        try {
            System.out.println("Introduce un numero > que cero: ");
            num = entrada.nextInt();
            while(num<0) {
                System.out.println("Introduce un numero > que cero: ");
                num = entrada.nextInt();
            }
            System.out.println("El numero introducido es: "+num);
        }
        catch(InputMismatchException e) {
            num = 0;
            System.out.println("El numero debe ser entero "+e.toString());
        }
    }
}

// Cada catch debe presentar como parámetro un objeto de la clase
// Throwable, de una clase derivada de esta o de una clase definida por
// el programador o la programadora. Cuando se lanza una excepción,
// se captura por el primer bloque catch cuyo parámetro pertenezca a la
// misma clase que el objeto excepción o a una clase base directa o
// indirecta. Por este motivo, el orden en que se coloquen los bloques
// catch es importante.

// Las excepciones más genéricas se deben capturar al final.
// Si no es necesario tratar excepciones concretas de forma específica,
// se puede utilizar un bloque catch de una clase base que las capture
// todas y las trate de forma general. Este proceso se conoce como
// captura genérica de excepciones.

// En el ejemplo, observamos cómo dentro del bloque try se solicita un
// número por teclado. Si el usuario o la usuaria introduce un número
// negativo, se abrirá un bucle pidiéndole que inserte de nuevo un número,
// y no se saldrá de dicho bucle hasta que ese número sea positivo.
// Si todo va bien, se imprimira el número por pantalla, pero si el
// usuario o la usuaria introduce un número decimal o un carácter
// tipo letra por ejemplo, se lanzará la excepción.


