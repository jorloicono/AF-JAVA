package LAMBDAS;

interface OperacionMatematica {
    int operar(int a, int b);
}
