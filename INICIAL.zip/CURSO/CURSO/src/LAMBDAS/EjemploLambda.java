package LAMBDAS;

public class EjemploLambda {
    public static void main(String[] args) {
        // Implementación de la interfaz funcional mediante una expresión lambda
        MiInterfazFuncional miLambda = () -> System.out.println("Hola desde la expresión lambda");

        // Llamada al método de la interfaz funcional
        miLambda.miMetodo();
    }
}
