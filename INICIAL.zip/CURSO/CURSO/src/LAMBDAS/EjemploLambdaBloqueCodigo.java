package LAMBDAS;

public class EjemploLambdaBloqueCodigo {
    public static void main(String[] args) {
        // Implementación de la interfaz funcional mediante una expresión lambda con bloque de código
        Saludo saludo = (nombre) -> {
            String mensaje = "Hola, " + nombre + "!";
            System.out.println(mensaje);
        };

        // Llamada al método de la interfaz funcional
        saludo.saludar("Juan");
    }
}
