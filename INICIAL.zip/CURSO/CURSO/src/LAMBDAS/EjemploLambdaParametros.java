package LAMBDAS;

public class EjemploLambdaParametros {
    public static void main(String[] args) {
        // Implementación de la interfaz funcional mediante una expresión lambda
        OperacionMatematica suma = (a, b) -> a + b;
        OperacionMatematica resta = (a, b) -> a - b;

        // Llamadas a los métodos de la interfaz funcional
        System.out.println("Suma: " + suma.operar(5, 3));
        System.out.println("Resta: " + resta.operar(5, 3));
    }
}