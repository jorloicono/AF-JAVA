package INTERFACES;
// Otra implementación de la interfaz en una clase diferente
class Pajaro implements Animal {
    @Override
    public void hacerSonido() {
        System.out.println("El pájaro canta");
    }

    @Override
    public void moverse() {
        System.out.println("El pájaro vuela");
    }
}
