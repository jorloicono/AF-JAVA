package LISTS;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class METODOSUTILES{
        public static void main(String[] args) {
            List<String> list = Arrays.asList(
                    "freeCodeCamp",
                    "let's",
                    "create");

            List<String> list2 = Collections.nCopies(10, "HELLO");
            System.out.println(list2);

            List list3 = new ArrayList<String>();
            list3.add("Hello");
            List list4 = list3;
            list4.add(" World");

            System.out.println(list3);
            System.out.println(list4);

            List<Integer> toBeSorted = new ArrayList<>(List.of(3,2,4,1,-2));
            Collections.sort(toBeSorted);
            System.out.println(toBeSorted);

            List<String> letters = new ArrayList<String>();

            // add example
            letters.add("A");
            letters.add("B");
            letters.add("C");

            //convert list to array
            String[] strArray = new String[letters.size()];
            strArray = letters.toArray(strArray);
            System.out.println(Arrays.toString(strArray)); //will print "[A, B, C]"

            String[] vowels = {"a","e","i","o","u"};

            List<String> vowelsList = Arrays.asList(vowels);
            System.out.println(vowelsList);

            //using for loop to copy elements from array to list, safe for modification of list
            List<String> myList = new ArrayList<>();
            for(String s : vowels){
                myList.add(s);
            }
            System.out.println(myList);
        }
}

/* Es posible crear y completar la lista con algunos elementos en una sola línea.
Hay dos maneras de hacer esto.

 Debes tener cuidado con una cosa al usar este método: Arrays.asList devuelve
 una lista inmutable. Entonces, si intentas agregar o eliminar elementos
 después de crear el objeto, obtendrás una excepción
 UnsupportedOperationException.

Java proporciona un método llamado NCopies que es especialmente útil para
la evaluación comparativa. Puedes llenar un arreglo con cualquier número
de elementos en una sola línea.

La variable list3 contiene una referencia a la lista li.
Cuando lo asignamos a list4 también apunta al mismo objeto.
Si no queremos que cambie la lista original, podemos clonar la lista.

Para ordenar una lista podemos usar Collections.sort.
Ordena en orden ascendente de forma predeterminada, pero también puedes
pasar un comparador para ordenar con lógica personalizada.

En general, la operación get (obtener) es mucho más rápida en ArrayList,
pero add (agregar) y remove (eliminar) son más rápidos en LinkedList.

ArrayList usa un arreglo detrás de escena, y cada vez que se elimina un
elemento, los elementos de el arreglo deben cambiarse
(que es una operación O (n)).

Elegir estructuras de datos es una tarea compleja y
no existe una receta que se aplique a todas las situaciones.
Aún así, intentaré proporcionar algunas pautas para
ayudarte a tomar esa decisión más fácilmente:

Si planeas hacer más operaciones de obtener y agregar que no
sean eliminar, usa ArrayList ya que la operación de obtener
es demasiado costosa en LinkedList. Tenga en cuenta que la inserción es
O(1) solo si la llamas sin especificar el índice y la agrega al final de la lista.

Si vas a eliminar elementos y/o insertarlos en el medio (no al final)
con frecuencia, puedes considerar cambiar a LinkedList
porque estas operaciones son costosas en ArrayList.

Ten en cuenta que si accedes a los elementos secuencialmente
(con un iterador), no experimentarás una pérdida de rendimiento con
LinkedList mientras obtienes elementos.
*/