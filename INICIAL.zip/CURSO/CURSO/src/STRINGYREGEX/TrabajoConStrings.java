package STRINGYREGEX;

public class TrabajoConStrings {

    public static void main(String[] args) {

        // Métodos de la clase String
        System.out.println("=== MÉTODOS DE LA CLASE STRING ===");

        String ejemplo = "ejemplo";
        System.out.println("Length: " + ejemplo.length()); // 7
        System.out.println("charAt(3): " + ejemplo.charAt(3)); // 'm'
        System.out.println("substring(4): " + ejemplo.substring(4)); // "plo"
        System.out.println("substring(4,10): " + "ejemploDestring".substring(4,10)); // "ploDeS"

        String s1 = "ejemplo";
        String s2 = "DeString";
        String salida = s1.concat(s2);
        System.out.println("concat: " + salida); // "ejemploDeString"

        String texto = "Ejemplo de cadena de texto";
        System.out.println("indexOf(\"texto\"): " + texto.indexOf("texto")); // 21

        String frase = "Estoy estudiando Java";
        System.out.println("indexOf('t', 5): " + frase.indexOf('t', 5)); // 8

        String texto2 = "Hola Mundo!";
        System.out.println("lastIndexOf('a'): " + texto2.lastIndexOf('a')); // 3

        System.out.println("\"Java\".equals(\"Java\"): " + "Java".equals("Java")); // true
        System.out.println("\"Java\".equals(\"java\"): " + "Java".equals("java")); // false

        System.out.println("\"Java\".equalsIgnoreCase(\"java\"): " + "Java".equalsIgnoreCase("java")); // true

        int compare = s1.compareTo(s2);
        System.out.println("compareTo: " + compare); // <0 o >0 o 0

        int compareIgnore = s1.compareToIgnoreCase(s2);
        System.out.println("compareToIgnoreCase: " + compareIgnore); // <0 o >0 o 0

        String escritor = "Miguel de Cervantes";
        System.out.println("toLowerCase: " + escritor.toLowerCase());

        String poeta = "Antonio Machado";
        System.out.println("toUpperCase: " + poeta.toUpperCase());

        String novela = "En un lugar de la Mancha ";
        System.out.println("trim: \"" + novela.trim() + "\"");

        String txt = "Estudiando Yava";
        System.out.println("replace('Y','J'): " + txt.replace('Y','J'));

        // StringBuilder
        System.out.println("\n=== STRINGBUILDER ===");
        StringBuilder sbuilder = new StringBuilder();
        long inicioSB = System.currentTimeMillis();

        for(int i=0; i<1000000; i++) {
            sbuilder.append("En un lugar de la Mancha, de cuyo nombre no quiero acordarme...");
        }

        long finSB = System.currentTimeMillis();
        System.out.println("Tiempo del StringBuilder = " + (finSB - inicioSB) + " ms");

        // StringBuffer
        System.out.println("\n=== STRINGBUFFER ===");
        StringBuffer sbuffer = new StringBuffer();
        long inicioSF = System.currentTimeMillis();

        for(int i=0; i<1000000; i++) {
            sbuffer.append("En un lugar de la Mancha, de cuyo nombre no quiero acordarme...");
        }

        long finSF = System.currentTimeMillis();
        System.out.println("Tiempo del StringBuffer = " + (finSF - inicioSF) + " ms");
    }
}
