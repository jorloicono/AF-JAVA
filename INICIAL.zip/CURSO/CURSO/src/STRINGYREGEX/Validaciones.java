package STRINGYREGEX;

import java.util.regex.Pattern;

public class Validaciones {

    // Método para validar fechas en formato dd/mm/yyyy
    public static boolean validarFecha(String fecha) {
        String fechaValida = "^(?:3[01]|[12][0-9]|0?[1-9])([\\-/.])(0?[1-9]|1[1-2])\\1\\d{4}$";
        return Pattern.matches(fechaValida, fecha);
    }

    // Método para validar DNI
    public static boolean validarDNI(String dni) {
        String dniPattern = "^[0-9]{8}[A-HJ-NP-TV-Z]$"; // Excluye I, O, U
        return Pattern.matches(dniPattern, dni);
    }

    // Método para validar email
    public static boolean validarEmail(String email) {
        String mailPattern = "^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@[A-Za-z0-9-]+(\\.[A-Za-z]{2,})$";
        return Pattern.matches(mailPattern, email);
    }

    public static void main(String[] args) {
        // Ejemplos de validación de fechas
        System.out.println("Validación de fechas:");
        System.out.println(validarFecha("21/12/2022")); // true
        System.out.println(validarFecha("1/12/2022"));  // true
        System.out.println(validarFecha("15/2/2022"));  // true
        System.out.println(validarFecha("11/12/22"));  // false
        System.out.println(validarFecha("11//2022"));   // false
        System.out.println(validarFecha("11/mayo/2022")); // false

        // Ejemplos de validación de DNI
        System.out.println("\nValidación de DNI:");
        System.out.println(validarDNI("46127582J")); // true
        System.out.println(validarDNI("46127582j")); // true
        System.out.println(validarDNI("6127582J"));  // false
        System.out.println(validarDNI("46127582-J")); // false

        // Ejemplos de validación de email
        System.out.println("\nValidación de Email:");
        System.out.println(validarEmail("info@gmail.com")); // true
        System.out.println(validarEmail("info.java@gmail.es")); // true
        System.out.println(validarEmail("info_java@gmail.com")); // true
        System.out.println(validarEmail("info@yahoo.gmail.com")); // false
        System.out.println(validarEmail("@gmail.com")); // false
        System.out.println(validarEmail("info@@gmail.com")); // false
        System.out.println(validarEmail("info@gmail.c")); // false
    }
}

