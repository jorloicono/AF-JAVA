package SETMAP.HASHCODE;

public class Persona {
        String nombre;

        Persona(String nombre) {
            this.nombre = nombre;
        }

        @Override
        public boolean equals(Object o) {
            if (this == o) return true;
            if (!(o instanceof Persona)) return false;
            Persona p = (Persona) o;
            return nombre.equals(p.nombre);
        }

        @Override
        public int hashCode() {
            return nombre.hashCode();
        }
    }

