package SETMAP.HASHCODE;

import java.util.HashSet;
import java.util.Set;

    public class TestSet {
        public static void main(String[] args) {
            Set<Persona> personas = new HashSet<>();
            personas.add(new Persona("Elena"));

            System.out.println(personas.contains(new Persona("Elena"))); // true
        }
    }


