package SETMAP;

// Java Program Demonstrating Working of Set by
// Adding elements using add() method

// Importing all utility classes
import java.util.*;

// Main class
public class AÑADIRELEMENTOSSET {

    // Main driver method
    public static void main(String[] args)
    {
        // Creating an object of Set and
        // declaring object of type String
        Set<String> hs = new HashSet<String>();

        // Adding elements to above object
        // using add() method
        hs.add("B");
        hs.add("B");
        hs.add("C");
        hs.add("A");

        // Printing the elements inside the Set object
        System.out.println(hs);
    }
}

