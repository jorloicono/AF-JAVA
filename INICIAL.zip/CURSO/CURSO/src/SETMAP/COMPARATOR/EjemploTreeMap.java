package SETMAP.COMPARATOR;

import java.util.*;

public class EjemploTreeMap {
    public static void main(String[] args) {
        // Comparator que ordena por longitud del nombre
        Comparator<Persona> porLongitud = (p1, p2) -> {
            int cmp = Integer.compare(p1.nombre.length(), p2.nombre.length());
            if (cmp == 0) {
                return p1.nombre.compareTo(p2.nombre); // si tienen misma longitud, orden alfabético
            }
            return cmp;
        };

        TreeMap<Persona, Integer> mapa = new TreeMap<>(porLongitud);

        mapa.put(new Persona("Ana"), 30);
        mapa.put(new Persona("Marta"), 25);
        mapa.put(new Persona("José"), 40);
        mapa.put(new Persona("Juan"), 35);
        mapa.put(new Persona("Cristina"), 28);

        for (Map.Entry<Persona, Integer> entry : mapa.entrySet()) {
            System.out.println(entry.getKey() + " → " + entry.getValue());
        }
    }
}

