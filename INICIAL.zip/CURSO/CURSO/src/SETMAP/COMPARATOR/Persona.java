package SETMAP.COMPARATOR;

public class Persona {
    String nombre;

    Persona(String nombre) {
        this.nombre = nombre;
    }

    @Override
    public String toString() {
        return nombre;
    }
}

