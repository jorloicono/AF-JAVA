package CLASESANIDADAS;

class ClaseExterior {
    void metodo(){
         int numero = 10;

        // Clase anidada estática
        class ClaseInternaLocal {
            void mostrar() {
                // Puede acceder a miembros estáticos de la clase externa
                System.out.println("Número: " + numero);

            }
        }
        ClaseInternaLocal claseInternaLocal = new ClaseInternaLocal();
        claseInternaLocal.mostrar();
    }
}



