package CLASESANIDADAS;

interface Producto {
    void mostrar();
}
