package CLASESANIDADAS;

public class Test {
    public static void main(String[] args) {
        // Instanciando una clase interna anónima para implementar la interfaz Producto
        Producto producto = new Producto() {
            public void mostrar() {
                System.out.println("Producto: Ordenador");
            }
        };

        producto.mostrar();
    }
}