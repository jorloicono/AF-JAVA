package LECTURAESCRITURA;

import java.io.*;

public class EscrituraArchivoTexto {

    public static void main(String[] args) {
        System.out.println("Volcando a fichero de texto… ");

        try {
            // Creamos el flujo de salida hacia el archivo
            BufferedWriter ficheroSalida = new BufferedWriter(
                    new FileWriter(new File("C:\\Users\\Jorge\\Desktop\\CURSO\\CURSO\\src\\LECTURAESCRITURA\\fichero.txt"))
            );

            // Escribimos líneas en el archivo
            ficheroSalida.write("Hola");
            ficheroSalida.newLine(); // salto de línea

            ficheroSalida.write("Este es");
            ficheroSalida.write(" un fichero de texto");
            ficheroSalida.newLine();

            // Cerramos el flujo para guardar correctamente los datos
            ficheroSalida.close();

        } catch (IOException errorDeFichero) {
            System.out.println("Ha habido problemas: " + errorDeFichero.getMessage());
        }
    }
}
