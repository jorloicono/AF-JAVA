package LECTURAESCRITURA;

import java.io.*;

public class LecturaArchivoTexto {

    public static void main(String[] args) {
        // Paso 1: Comprobamos si el archivo existe
        File archivo = new File("C:\\Users\\Jorge\\Desktop\\CURSO\\CURSO\\src\\LECTURAESCRITURA\\Fichero.txt");
        if (!archivo.exists()) {
            System.out.println("No he encontrado Fichero.txt");
        }

        System.out.println("Leyendo el fichero de texto");

        // Paso 2: Intentamos leer el archivo línea por línea
        try {
            BufferedReader ficheroEntrada = new BufferedReader(new FileReader(archivo));
            String linea = null;

            while ((linea = ficheroEntrada.readLine()) != null) {
                System.out.println(linea);
            }

            ficheroEntrada.close(); // Cerramos el archivo después de leerlo

        } catch (IOException errorDeFichero) {
            System.out.println("Ha habido problemas: " + errorDeFichero.getMessage());
        }
    }
}

