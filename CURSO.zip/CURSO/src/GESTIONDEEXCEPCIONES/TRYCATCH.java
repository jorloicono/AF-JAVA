package GESTIONDEEXCEPCIONES;

public class TRYCATCH {
    public static void main(String[] args) {

        //Declaracion de variables
        int num1 = 15;
        int num2 = 20;
        int num3 = 0;
        double operacion = 0;

        try {
            //Operacion aritmetica que divide por cero
            operacion = (num1+num2)/num3;
            System.out.println("El resultado de la operacion es: "+operacion);
        }
        catch(ArithmeticException e) {
            System.out.println("No se puede dividir entre cero");
            System.out.println("Prueba con otro valor");
        }
    }
}

/*En este ejemplo, vemos nuevamente una división entre cero,
pero esta vez se ha recurrido a la estructura try - catch que acabamos
de mencionar. Dentro del bloque try, se encuentra la instrucción o
instrucciones que producen la excepción, en este caso una ArithmeticException.
En el bloque catch, capturamos esta excepción e indicamos lo que debe ejecutar
el programa en el caso de que esta ocurra, obteniendo como resultado:

No se puede dividir entre cero
Prueba con otro valor

Como podemos comprobar, el programa no se ha detenido durante su ejecución,
sino que ha continuado hasta el final. Este ejemplo es muy breve, pero en un
programa complejo con cientos o miles de líneas de código,
el tratamiento de excepciones es fundamental.
 */