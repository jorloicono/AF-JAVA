package GESTIONDEEXCEPCIONES.EXCEPCIONPERSONALIAZDA;

public class DemoExcepciones {
    public static void main(String[] args) {
        try {
            // Intentar crear una persona con edad no válida
            Persona persona = new Persona("Juan", 160);
            persona.saludar();
        } catch (EdadInvalidaException e) {
            // Capturar y manejar la excepción personalizada
            System.out.println("Error: " + e.getMessage());
        }
    }
}
