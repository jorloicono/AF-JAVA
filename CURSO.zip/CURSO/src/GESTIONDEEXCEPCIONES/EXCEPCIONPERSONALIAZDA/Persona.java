package GESTIONDEEXCEPCIONES.EXCEPCIONPERSONALIAZDA;

class Persona {
    private String nombre;
    private int edad;

    public Persona(String nombre, int edad) throws EdadInvalidaException {
        // Validar la edad
        if (edad < 0 || edad > 150) {
            // Lanzar la excepción personalizada si la edad no es válida
            throw new EdadInvalidaException("La edad proporcionada no es válida");
        }

        this.nombre = nombre;
        this.edad = edad;
    }

    public void saludar() {
        System.out.println("Hola, soy " + nombre + " y tengo " + edad + " años.");
    }
}

/* En este ejemplo, la clase EdadInvalidaException extiende la clase
Exception para crear una excepción personalizada. La clase Persona tiene
un constructor que recibe el nombre y la edad como parámetros. Antes de asignar
la edad, verifica si está en el rango válido (entre 0 y 150 años). Si la edad no
es válida, se lanza la excepción personalizada.

En el método main, intentamos crear una instancia de Persona con una edad no
válida y capturamos la excepción personalizada (EdadInvalidaException).
Si la excepción se lanza, se imprime un mensaje de error. Este es solo un
ejemplo básico, y en aplicaciones más complejas, las excepciones personalizadas
pueden contener más información o lógica específica.
*/