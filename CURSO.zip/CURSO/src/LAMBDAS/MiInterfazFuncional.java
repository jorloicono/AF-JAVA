package LAMBDAS;

/*Al utilizar expresiones lambda en Java, estás esencialmente proporcionando
una implementación de una interfaz funcional. Una interfaz funcional
es una interfaz de Java que tiene exactamente un método abstracto (un método
sin implementación). Este tipo de interfaz se utiliza en el contexto de la
programación funcional y es fundamental para el funcionamiento de las expresiones
lambda.


La principal razón por la que necesitas una interfaz funcional al usar
expresiones lambda es que las expresiones lambda en Java se usan para
proporcionar implementaciones concisas de interfaces funcionales. La interfaz
funcional actúa como un tipo que define el contrato para la expresión lambda.
La expresión lambda en sí misma representa una instancia de esa interfaz funcional.

Las expresiones lambda permiten tratar las funciones como objetos, facilitan
la programación funcional y proporcionan una forma más concisa de expresar
comportamientos en comparación con las clases anónimas.
*/
interface MiInterfazFuncional {

    void miMetodo();
}