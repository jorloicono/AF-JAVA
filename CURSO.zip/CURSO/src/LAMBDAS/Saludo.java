package LAMBDAS;

interface Saludo {
    void saludar(String nombre);
}