package EJERCICIOS.EJERCICIO25;

import java.util.InputMismatchException;
import java.util.Scanner;

public class SistemaCuentasBancarias {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        try {
            // Crear una instancia de CuentaBancaria con un saldo inicial
            System.out.print("Ingrese el saldo inicial de la cuenta bancaria: ");
            double saldoInicial = scanner.nextDouble();
            CuentaBancaria cuenta = new CuentaBancaria(saldoInicial);

            // Realizar un depósito
            System.out.print("Ingrese el monto a depositar: ");
            double montoDeposito = scanner.nextDouble();
            cuenta.realizarDeposito(montoDeposito);
            System.out.println("Depósito exitoso. Saldo actual: " + cuenta.getSaldo());

            // Realizar un retiro
            System.out.print("Ingrese el monto a retirar: ");
            double montoRetiro = scanner.nextDouble();
            cuenta.realizarRetiro(montoRetiro);
            System.out.println("Retiro exitoso. Saldo actual: " + cuenta.getSaldo());

        } catch (InputMismatchException e) {
            System.out.println("Error: Ingrese un valor numérico válido.");
        } catch (IllegalArgumentException e) {
            System.out.println("Error: " + e.getMessage());
        } finally {
            scanner.close();
        }
    }
}