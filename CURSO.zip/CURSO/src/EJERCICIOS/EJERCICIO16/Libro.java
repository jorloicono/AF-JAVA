package EJERCICIOS.EJERCICIO16;

class Libro {
    private String titulo;
    private String autor;
    private int añoPublicacion;
    private boolean disponible;

    public Libro(String titulo, String autor, int añoPublicacion) {
        this.titulo = titulo;
        this.autor = autor;
        this.añoPublicacion = añoPublicacion;
        this.disponible = true;
    }

    // Métodos de acceso
    public String getTitulo() {
        return titulo;
    }

    public String getAutor() {
        return autor;
    }

    public int getAñoPublicacion() {
        return añoPublicacion;
    }

    public boolean isDisponible() {
        return disponible;
    }

    // Método para cambiar el estado de disponibilidad del libro
    public void setDisponible(boolean disponible) {
        this.disponible = disponible;
    }
}
