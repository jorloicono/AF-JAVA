package EJERCICIOS.EJERCICIO16;

class Biblioteca {
    private Libro[] librosDisponibles;
    private Libro[] librosPrestados;
    private Lector[] lectoresRegistrados;
    private int librosDisponiblesCount;
    private int librosPrestadosCount;
    private int lectoresRegistradosCount;

    public Biblioteca(int maxLibros, int maxLectores) {
        this.librosDisponibles = new Libro[maxLibros];
        this.librosPrestados = new Libro[maxLibros];
        this.lectoresRegistrados = new Lector[maxLectores];
        this.librosDisponiblesCount = 0;
        this.librosPrestadosCount = 0;
        this.lectoresRegistradosCount = 0;
    }

    // Métodos para agregar libros a la biblioteca
    public void agregarLibro(Libro libro) {
        if (librosDisponiblesCount < librosDisponibles.length) {
            librosDisponibles[librosDisponiblesCount] = libro;
            librosDisponiblesCount++;
        } else {
            System.out.println("No se pueden agregar más libros a la biblioteca");
        }
    }

    // Métodos para prestar y devolver libros
    public void prestarLibro(Libro libro, Lector lector) {
        if (libro.isDisponible()) {
            libro.setDisponible(false);
            librosPrestados[librosPrestadosCount] = libro;
            librosPrestadosCount++;
            lector.prestarLibro(libro);
            System.out.println("Libro prestado a " + lector.getNombre() + ": " + libro.getTitulo());
        } else {
            System.out.println("El libro no está disponible para préstamo.");
        }
    }

    public void devolverLibro(Libro libro, Lector lector) {
        libro.setDisponible(true);
        lector.devolverLibro(libro);
        System.out.println("Libro devuelto por " + lector.getNombre() + ": " + libro.getTitulo());
    }

    // Método para registrar un lector en la biblioteca
    public void registrarLector(Lector lector) {
        if (lectoresRegistradosCount < lectoresRegistrados.length) {
            lectoresRegistrados[lectoresRegistradosCount] = lector;
            lectoresRegistradosCount++;
        } else {
            System.out.println("No se pueden registrar más lectores en la biblioteca");
        }
    }

    // Método para mostrar información sobre libros disponibles y lectores registrados
    public void mostrarInformacion() {
        System.out.println("Libros disponibles:");
        for (int i = 0; i < librosDisponiblesCount; i++) {
            System.out.println(librosDisponibles[i].getTitulo() + " - " + librosDisponibles[i].getAutor());
        }

        System.out.println("\nLectores registrados:");
        for (int i = 0; i < lectoresRegistradosCount; i++) {
            System.out.println(lectoresRegistrados[i].getNombre() + " - " + lectoresRegistrados[i].getId());
        }
    }
}
