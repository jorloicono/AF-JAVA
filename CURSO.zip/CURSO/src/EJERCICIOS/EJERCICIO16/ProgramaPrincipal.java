package EJERCICIOS.EJERCICIO16;

public class ProgramaPrincipal {
    public static void main(String[] args) {
        // Crear instancias de libros, lectores y la biblioteca
        Libro libro1 = new Libro("Harry Potter", "J.K. Rowling", 2001);
        Libro libro2 = new Libro("Cien años de soledad", "Gabriel García Márquez", 1967);

        Lector lector1 = new Lector("Carlos", "123", 3);
        Lector lector2 = new Lector("Ana", "456", 2);

        Biblioteca biblioteca = new Biblioteca(5, 2);

        // Agregar libros a la biblioteca
        biblioteca.agregarLibro(libro1);
        biblioteca.agregarLibro(libro2);

        // Registrar lectores en la biblioteca
        biblioteca.registrarLector(lector1);
        biblioteca.registrarLector(lector2);

        // Prestar libros a los lectores
        biblioteca.prestarLibro(libro1, lector1);
        biblioteca.prestarLibro(libro2, lector2);

        // Mostrar información relevante
        biblioteca.mostrarInformacion();
    }
}
