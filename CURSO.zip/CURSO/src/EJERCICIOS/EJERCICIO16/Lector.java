package EJERCICIOS.EJERCICIO16;

class Lector {
    private String nombre;
    private String id;
    private Libro[] librosPrestados;
    private int librosPrestadosCount;

    public Lector(String nombre, String id, int maxLibrosPrestados) {
        this.nombre = nombre;
        this.id = id;
        this.librosPrestados = new Libro[maxLibrosPrestados];
        this.librosPrestadosCount = 0;
    }

    // Métodos de acceso
    public String getNombre() {
        return nombre;
    }

    public String getId() {
        return id;
    }

    public Libro[] getLibrosPrestados() {
        return librosPrestados;
    }

    // Método para prestar un libro al lector
    public void prestarLibro(Libro libro) {
        if (librosPrestadosCount < librosPrestados.length) {
            librosPrestados[librosPrestadosCount] = libro;
            librosPrestadosCount++;
        } else {
            System.out.println("No se pueden prestar más libros a " + nombre);
        }
    }

    // Método para devolver un libro a la biblioteca
    public void devolverLibro(Libro libro) {
        for (int i = 0; i < librosPrestadosCount; i++) {
            if (librosPrestados[i].equals(libro)) {
                librosPrestados[i] = null;
                rearrangeLibrosPrestados(i);
                librosPrestadosCount--;
                break;
            }
        }
    }

    // Método para reorganizar el array de libros prestados después de la devolución
    private void rearrangeLibrosPrestados(int index) {
        for (int i = index; i < librosPrestadosCount - 1; i++) {
            librosPrestados[i] = librosPrestados[i + 1];
        }
    }
}
