package EJERCICIOS.EJERCICIO17;

class Usuario implements Autenticable {
    private String nombreUsuario;
    private String contraseña;

    public Usuario(String nombreUsuario, String contraseña) {
        this.nombreUsuario = nombreUsuario;
        this.contraseña = contraseña;
    }

    // Implementación del método autenticar para Usuario
    @Override
    public boolean autenticar(String nombreUsuario, String contraseña) {
        return this.nombreUsuario.equals(nombreUsuario) && this.contraseña.equals(contraseña);
    }
}
