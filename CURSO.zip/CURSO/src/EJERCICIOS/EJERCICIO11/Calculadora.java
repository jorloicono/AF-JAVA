package EJERCICIOS.EJERCICIO11;

public class Calculadora {
    // Método para la suma
    public double suma(double num1, double num2) {
        return num1 + num2;
    }

    // Método para la resta
    public double resta(double num1, double num2) {
        return num1 - num2;
    }

    // Método para la multiplicación
    public double multiplicacion(double num1, double num2) {
        return num1 * num2;
    }

    // Método para la división
    public double division(double num1, double num2) {
        if (num2 != 0) {
            return num1 / num2;
        } else {
            System.out.println("Error: División por cero no permitida.");
            return Double.NaN; // NaN (Not a Number) como resultado de la división por cero
        }
    }

    // Método main para probar la clase
    public static void main(String[] args) {
        // Crear una instancia de la calculadora
        Calculadora calculadora = new Calculadora();

        // Realizar algunas operaciones y mostrar los resultados
        double resultadoSuma = calculadora.suma(10, 5);
        System.out.println("Suma: " + resultadoSuma);

        double resultadoResta = calculadora.resta(10, 5);
        System.out.println("Resta: " + resultadoResta);

        double resultadoMultiplicacion = calculadora.multiplicacion(10, 5);
        System.out.println("Multiplicación: " + resultadoMultiplicacion);

        double resultadoDivision = calculadora.division(10, 5);
        System.out.println("División: " + resultadoDivision);

        // Intentar dividir por cero
        double resultadoDivisionCero = calculadora.division(10, 0);
        // El resultado será NaN y se mostrará un mensaje de error
    }
}

