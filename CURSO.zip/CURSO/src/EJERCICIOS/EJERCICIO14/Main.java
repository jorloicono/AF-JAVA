package EJERCICIOS.EJERCICIO14;

// Programa principal
public class Main {
    public static void main(String[] args) {
        // Crear instancias de Círculo, Rectángulo y Triángulo
        Circulo miCirculo = new Circulo(5);
        Rectangulo miRectangulo = new Rectangulo(4, 6);
        Triangulo miTriangulo = new Triangulo(3, 4, 5);

        // Mostrar resultados de los cálculos
        System.out.println("Área y Perímetro del Círculo:");
        System.out.println("Área: " + miCirculo.calcularArea());
        System.out.println("Perímetro: " + miCirculo.calcularPerimetro());

        System.out.println("\nÁrea y Perímetro del Rectángulo:");
        System.out.println("Área: " + miRectangulo.calcularArea());
        System.out.println("Perímetro: " + miRectangulo.calcularPerimetro());

        System.out.println("\nÁrea y Perímetro del Triángulo:");
        System.out.println("Área: " + miTriangulo.calcularArea());
        System.out.println("Perímetro: " + miTriangulo.calcularPerimetro());
    }
}
