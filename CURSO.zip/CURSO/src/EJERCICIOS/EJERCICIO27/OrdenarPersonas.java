package EJERCICIOS.EJERCICIO27;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class OrdenarPersonas {
    public static void main(String[] args) {
        // Crear una lista de objetos Persona
        List<Persona> listaPersonas = new ArrayList<>();
        listaPersonas.add(new Persona("Juan", 25));
        listaPersonas.add(new Persona("Ana", 30));
        listaPersonas.add(new Persona("Luis", 22));

        // Imprimir la lista antes de ordenar
        System.out.println("Lista antes de ordenar:");
        for (Persona persona : listaPersonas) {
            System.out.println(persona);
        }

        // Ordenar la lista por edad
        Collections.sort(listaPersonas, Comparator.comparingInt(Persona::getEdad));

        // Imprimir la lista después de ordenar
        System.out.println("\nLista después de ordenar por edad:");
        for (Persona persona : listaPersonas) {
            System.out.println(persona);
        }
    }
}
