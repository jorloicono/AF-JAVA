package EJERCICIOS;
import java.util.Scanner;

public class EJERCICIO19 {

    public class VerificarCapicuaConBucles {

        public static void main(String[] args) {
            Scanner scanner = new Scanner(System.in);
            int numero;

            do {
                System.out.print("Ingresa un número entero de más de una cifra: ");
                while (!scanner.hasNextInt()) {
                    System.out.print("Por favor, ingresa un número entero válido: ");
                    scanner.next();
                }
                numero = scanner.nextInt();
            } while (numero < 10);

            int original = numero;
            int invertido = 0;

            while (numero > 0) {
                int digito = numero % 10;
                invertido = invertido * 10 + digito;
                numero /= 10;
            }

            if (original == invertido) {
                System.out.println(original + " es un número capicúa.");
            } else {
                System.out.println(original + " no es un número capicúa.");
            }

            scanner.close();

            String numeroComoCadena = Integer.toString(numero);
            boolean esCapicua = true;

            for (int i = 0; i < numeroComoCadena.length() / 2; i++) {
                if (numeroComoCadena.charAt(i) != numeroComoCadena.charAt(numeroComoCadena.length() - 1 - i)) {
                    esCapicua = false;
                    break;
                }
            }

            if (esCapicua) {
                System.out.println(numero + " es un número capicúa.");
            } else {
                System.out.println(numero + " no es un número capicúa.");
            }
        }
    }
}


