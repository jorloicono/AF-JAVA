package EJERCICIOS;
import java.util.Arrays;

public class EJERCICIO21 {

    public static void main(String[] args) {
        double[] temperaturasSemana = {25.5, 27.0, 23.5, 22.0, 26.8, 28.2, 24.0};

        System.out.println("Temperatura Media: " + calcularTemperaturaMedia(temperaturasSemana));
        System.out.println("Temperatura Máxima: " + encontrarTemperaturaMaxima(temperaturasSemana));
        System.out.println("Temperatura Mediana: " + encontrarTemperaturaMediana(temperaturasSemana));
    }

    public static double calcularTemperaturaMedia(double[] temperaturas) {
        double suma = 0;
        for (double temperatura : temperaturas) {
            suma += temperatura;
        }
        return suma / temperaturas.length;
    }

    public static double encontrarTemperaturaMaxima(double[] temperaturas) {
        double maxima = temperaturas[0];
        for (int i = 1; i < temperaturas.length; i++) {
            if (temperaturas[i] > maxima) {
                maxima = temperaturas[i];
            }
        }
        return maxima;
    }

    public static double encontrarTemperaturaMediana(double[] temperaturas) {
        // Ordenar el array
        Arrays.sort(temperaturas);

        // Calcular la mediana
        int n = temperaturas.length;
        if (n % 2 == 0) {
            // Si la cantidad de elementos es par, promedio de los dos elementos centrales
            return (temperaturas[n / 2 - 1] + temperaturas[n / 2]) / 2.0;
        } else {
            // Si la cantidad de elementos es impar, tomar el valor del medio
            return temperaturas[n / 2];
        }
    }
}

