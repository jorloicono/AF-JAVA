package EJERCICIOS.EJERCICIO18;

// Clase principal
public class Main {
    public static void main(String[] args) {
        // Crear una lista de empleados
        Empleado[] empleados = {
                new EmpleadoAsalariado("Juan", 3000),
                new EmpleadoPorHoras("María", 15, 40),
                new EmpleadoComision("Pedro", 10000, 0.1)
        };

        // Calcular y mostrar el salario de cada empleado
        for (Empleado empleado : empleados) {
            empleado.mostrarInformacion();
        }
    }
}
