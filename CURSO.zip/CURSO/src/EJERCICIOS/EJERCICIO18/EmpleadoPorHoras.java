package EJERCICIOS.EJERCICIO18;

// Clase EmpleadoPorHoras
class EmpleadoPorHoras implements Empleado {
    private String nombre;
    private double tarifaPorHora;
    private int horasTrabajadas;

    public EmpleadoPorHoras(String nombre, double tarifaPorHora, int horasTrabajadas) {
        this.nombre = nombre;
        this.tarifaPorHora = tarifaPorHora;
        this.horasTrabajadas = horasTrabajadas;
    }

    @Override
    public double calcularSalario() {
        return tarifaPorHora * horasTrabajadas;
    }

    @Override
    public void mostrarInformacion() {
        System.out.println("Empleado por Horas - Nombre: " + nombre + ", Salario: $" + calcularSalario());
    }
}
