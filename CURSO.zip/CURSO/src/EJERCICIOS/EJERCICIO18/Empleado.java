package EJERCICIOS.EJERCICIO18;

// Interfaz Empleado
interface Empleado {
    double calcularSalario();
    void mostrarInformacion();
}
