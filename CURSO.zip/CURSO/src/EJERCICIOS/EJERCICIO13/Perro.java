package EJERCICIOS.EJERCICIO13;

class Perro extends Animal {
    private String raza;

    // Constructor
    public Perro(String nombre, int edad, String raza) {
        super(nombre, edad);
        this.raza = raza;
    }

    // Método de acceso adicional
    public String getRaza() {
        return raza;
    }
}
