package EJERCICIOS.EJERCICIO13;

public class Main {
    public static void main(String[] args) {
        // Crear instancias de Perro y Gato
        Perro miPerro = new Perro("Max", 3, "Labrador");
        Gato miGato = new Gato("Whiskers", 2, "Gris");

        // Mostrar información básica de cada animal
        System.out.println("Información del Perro:");
        System.out.println("Nombre: " + miPerro.getNombre());
        System.out.println("Edad: " + miPerro.getEdad());
        System.out.println("Raza: " + miPerro.getRaza());

        System.out.println("\nInformación del Gato:");
        System.out.println("Nombre: " + miGato.getNombre());
        System.out.println("Edad: " + miGato.getEdad());
        System.out.println("Color del Pelaje: " + miGato.getColorPelaje());
    }
}
