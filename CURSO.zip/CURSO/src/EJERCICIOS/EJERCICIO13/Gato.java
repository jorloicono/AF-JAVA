package EJERCICIOS.EJERCICIO13;

class Gato extends Animal {
    private String colorPelaje;

    // Constructor
    public Gato(String nombre, int edad, String colorPelaje) {
        super(nombre, edad);
        this.colorPelaje = colorPelaje;
    }

    // Método de acceso adicional
    public String getColorPelaje() {
        return colorPelaje;
    }
}
