package EJERCICIOS.EJERCICIO13;

class Animal {
    private String nombre;
    private int edad;

    // Constructor
    public Animal(String nombre, int edad) {
        this.nombre = nombre;
        this.edad = edad;
    }

    // Métodos de acceso
    public String getNombre() {
        return nombre;
    }

    public int getEdad() {
        return edad;
    }
}
