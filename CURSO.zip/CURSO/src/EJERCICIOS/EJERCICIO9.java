package EJERCICIOS;

public class EJERCICIO9 {

    public static void main(String[] args) {
        String cadenaPrueba = "Hola, cómo estás? Áló!";

        // Convertir la cadena a minúsculas para ignorar mayúsculas
        String cadenaMinusculas = cadenaPrueba.toLowerCase();

        // Definir las vocales sin acentos
        char[] vocales = {'a', 'e', 'i', 'o', 'u'};

        int contadorVocales = 0;

        // Iterar sobre cada carácter en la cadena
        for (int i = 0; i < cadenaMinusculas.length(); i++) {
            char caracter = cadenaMinusculas.charAt(i);

            // Verificar si el carácter es una vocal sin acentos
            for (char vocal : vocales) {
                if (caracter == vocal) {
                    contadorVocales++;
                    break;
                }
            }
        }

        // Imprimir el número de vocales
        System.out.println("Número de vocales: " + contadorVocales);
    }
}
