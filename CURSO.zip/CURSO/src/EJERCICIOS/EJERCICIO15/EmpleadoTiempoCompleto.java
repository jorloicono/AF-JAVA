package EJERCICIOS.EJERCICIO15;

class EmpleadoTiempoCompleto extends Empleado {
    private String cargo;

    public EmpleadoTiempoCompleto(String nombre, int edad, double salario, String cargo) {
        super(nombre, edad, salario);
        this.cargo = cargo;
    }

    // Método específico para calcular el salario total
    public double calcularSalarioTotal() {
        return getSalario() + (0.1 * getSalario()); // Ejemplo: bono del 10%
    }

    // Método de acceso adicional
    public String getCargo() {
        return cargo;
    }
}
