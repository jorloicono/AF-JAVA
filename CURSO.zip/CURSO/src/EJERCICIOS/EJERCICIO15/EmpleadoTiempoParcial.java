package EJERCICIOS.EJERCICIO15;

class EmpleadoTiempoParcial extends Empleado {
    private int horasTrabajadas;
    private double tarifaPorHora;

    public EmpleadoTiempoParcial(String nombre, int edad, double salario, int horasTrabajadas, double tarifaPorHora) {
        super(nombre, edad, salario);
        this.horasTrabajadas = horasTrabajadas;
        this.tarifaPorHora = tarifaPorHora;
    }

    // Método específico para calcular el salario total
    public double calcularSalarioTotal() {
        return horasTrabajadas * tarifaPorHora;
    }

    // Métodos de acceso adicionales
    public int getHorasTrabajadas() {
        return horasTrabajadas;
    }

    public double getTarifaPorHora() {
        return tarifaPorHora;
    }
}
