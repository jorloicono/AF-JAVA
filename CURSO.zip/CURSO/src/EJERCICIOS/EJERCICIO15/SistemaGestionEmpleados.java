package EJERCICIOS.EJERCICIO15;

public class SistemaGestionEmpleados {
    public static void main(String[] args) {
        // Crear instancias de EmpleadoTiempoCompleto y EmpleadoTiempoParcial
        EmpleadoTiempoCompleto empleadoFullTime = new EmpleadoTiempoCompleto("Juan", 30, 50000, "Desarrollador");
        EmpleadoTiempoParcial empleadoPartTime = new EmpleadoTiempoParcial("Maria", 25, 20000, 20, 15.5);

        // Mostrar información detallada de cada empleado, incluyendo salario total
        System.out.println("Empleado a tiempo completo:");
        System.out.println("Nombre: " + empleadoFullTime.getNombre());
        System.out.println("Edad: " + empleadoFullTime.getEdad());
        System.out.println("Cargo: " + empleadoFullTime.getCargo());
        System.out.println("Salario total: " + empleadoFullTime.calcularSalarioTotal());

        System.out.println("\nEmpleado a tiempo parcial:");
        System.out.println("Nombre: " + empleadoPartTime.getNombre());
        System.out.println("Edad: " + empleadoPartTime.getEdad());
        System.out.println("Horas trabajadas: " + empleadoPartTime.getHorasTrabajadas());
        System.out.println("Tarifa por hora: " + empleadoPartTime.getTarifaPorHora());
        System.out.println("Salario total: " + empleadoPartTime.calcularSalarioTotal());
    }
}
