package EJERCICIOS;

import java.sql.*;
import java.util.Scanner;

public class EJERCICIO33 {

    private static final String URL = "jdbc:mysql://localhost:3306/JORGE";
    private static final String USER = "root";
    private static final String PASSWORD = "123123123";

    public static void main(String[] args) {
        try {
            // Establecer conexión con la base de datos
            Connection connection = DriverManager.getConnection(URL, USER, PASSWORD);

            // Crear la tabla si no existe
            crearTablaClientes(connection);

            // Menú de operaciones
            while (true) {
                System.out.println("1. Crear Cliente");
                System.out.println("2. Leer Clientes");
                System.out.println("3. Actualizar Cliente");
                System.out.println("4. Eliminar Cliente");
                System.out.println("5. Salir");

                // Obtener la opción del usuario
                System.out.print("Seleccione una opción: ");
                Scanner scanner = new Scanner(System.in);
                int opcion = scanner.nextInt();

                switch (opcion) {
                    case 1:
                        crearCliente(connection);
                        break;
                    case 2:
                        leerClientes(connection);
                        break;
                    case 3:
                        actualizarCliente(connection);
                        break;
                    case 4:
                        eliminarCliente(connection);
                        break;
                    case 5:
                        // Cerrar la conexión y salir
                        connection.close();
                        System.exit(0);
                        break;
                    default:
                        System.out.println("Opción no válida. Inténtalo de nuevo.");
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static void crearTablaClientes(Connection connection) throws SQLException {
        String createTableSQL = "CREATE TABLE IF NOT EXISTS clientes ("
                + "id INT PRIMARY KEY AUTO_INCREMENT,"
                + "nombre VARCHAR(255),"
                + "apellido VARCHAR(255),"
                + "edad INT)";
        try (Statement statement = connection.createStatement()) {
            statement.executeUpdate(createTableSQL);
        }
    }

    private static void crearCliente(Connection connection) throws SQLException {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Ingrese nombre del cliente: ");
        String nombre = scanner.nextLine();
        System.out.print("Ingrese apellido del cliente: ");
        String apellido = scanner.nextLine();
        System.out.print("Ingrese edad del cliente: ");
        int edad = scanner.nextInt();

        String insertSQL = "INSERT INTO clientes (nombre, apellido, edad) VALUES (?, ?, ?)";
        try (PreparedStatement preparedStatement = connection.prepareStatement(insertSQL)) {
            preparedStatement.setString(1, nombre);
            preparedStatement.setString(2, apellido);
            preparedStatement.setInt(3, edad);
            preparedStatement.executeUpdate();
        }

        System.out.println("Cliente creado con éxito.");
    }

    private static void leerClientes(Connection connection) throws SQLException {
        String selectSQL = "SELECT * FROM clientes";
        try (Statement statement = connection.createStatement();
             ResultSet resultSet = statement.executeQuery(selectSQL)) {
            while (resultSet.next()) {
                int id = resultSet.getInt("id");
                String nombre = resultSet.getString("nombre");
                String apellido = resultSet.getString("apellido");
                int edad = resultSet.getInt("edad");
                System.out.println("ID: " + id + ", Nombre: " + nombre + ", Apellido: " + apellido + ", Edad: " + edad);
            }
        }
    }

    private static void actualizarCliente(Connection connection) throws SQLException {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Ingrese el ID del cliente que desea actualizar: ");
        int idCliente = scanner.nextInt();

        System.out.println("¿Qué información desea actualizar?");
        System.out.println("1. Nombre");
        System.out.println("2. Apellido");
        System.out.println("3. Edad");

        System.out.print("Seleccione una opción: ");
        int opcion = scanner.nextInt();

        String columnaActualizar = "";
        switch (opcion) {
            case 1:
                columnaActualizar = "nombre";
                break;
            case 2:
                columnaActualizar = "apellido";
                break;
            case 3:
                columnaActualizar = "edad";
                break;
            default:
                System.out.println("Opción no válida.");
                return;
        }

        System.out.print("Ingrese el nuevo valor para " + columnaActualizar + ": ");
        String nuevoValor = scanner.next();

        String updateSQL = "UPDATE clientes SET " + columnaActualizar + " = ? WHERE id = ?";
        try (PreparedStatement preparedStatement = connection.prepareStatement(updateSQL)) {
            preparedStatement.setString(1, nuevoValor);
            preparedStatement.setInt(2, idCliente);
            int filasActualizadas = preparedStatement.executeUpdate();
            if (filasActualizadas > 0) {
                System.out.println("Actualización realizada con éxito.");
            } else {
                System.out.println("No se encontró ningún cliente con el ID proporcionado.");
            }
        }
    }

    private static void eliminarCliente(Connection connection) throws SQLException {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Ingrese el ID del cliente que desea eliminar: ");
        int idCliente = scanner.nextInt();

        String deleteSQL = "DELETE FROM clientes WHERE id = ?";
        try (PreparedStatement preparedStatement = connection.prepareStatement(deleteSQL)) {
            preparedStatement.setInt(1, idCliente);
            int filasEliminadas = preparedStatement.executeUpdate();
            if (filasEliminadas > 0) {
                System.out.println("Cliente eliminado con éxito.");
            } else {
                System.out.println("No se encontró ningún cliente con el ID proporcionado.");
            }
        }
    }
}

