package EJERCICIOS.EJERCICIO10;

public class Persona {
    // Atributos
    private String nombre;
    private String apellido;
    private String numeroDocumento;
    private int añoNacimiento;

    // Constructor
    public Persona(String nombre, String apellido, String numeroDocumento, int añoNacimiento) {
        this.nombre = nombre;
        this.apellido = apellido;
        this.numeroDocumento = numeroDocumento;
        this.añoNacimiento = añoNacimiento;
    }

    // Método para imprimir los valores de los atributos por pantalla
    public void imprimirDatos() {
        System.out.println("Nombre: " + nombre);
        System.out.println("Apellido: " + apellido);
        System.out.println("Número de Documento: " + numeroDocumento);
        System.out.println("Año de Nacimiento: " + añoNacimiento);
    }

    // Método main para probar la clase
    public static void main(String[] args) {
        // Crear dos personas
        Persona persona1 = new Persona("Juan", "Perez", "123456789", 1990);
        Persona persona2 = new Persona("Maria", "Gomez", "987654321", 1985);

        // Mostrar los valores de sus atributos por pantalla
        System.out.println("Datos de la Persona 1:");
        persona1.imprimirDatos();

        System.out.println("\nDatos de la Persona 2:");
        persona2.imprimirDatos();
    }
}

