package EJERCICIOS;

import java.util.ArrayList;
import java.util.Scanner;

public class EJERCICIO26 {

public static void main(String[] args) {
        ArrayList<String> listaNombres = new ArrayList<>();
        Scanner scanner = new Scanner(System.in);

        int opcion;

        do {
            System.out.println("\nMenú:");
            System.out.println("1. Agregar un nombre a la lista.");
            System.out.println("2. Eliminar un nombre de la lista.");
            System.out.println("3. Imprimir la lista de nombres.");
            System.out.println("4. Buscar un nombre en la lista.");
            System.out.println("5. Salir del programa.");
            System.out.print("Seleccione una opción (1-5): ");

            opcion = scanner.nextInt();

            switch (opcion) {
                case 1:
                    agregarNombre(listaNombres, scanner);
                    break;
                case 2:
                    eliminarNombre(listaNombres, scanner);
                    break;
                case 3:
                    imprimirLista(listaNombres);
                    break;
                case 4:
                    buscarNombre(listaNombres, scanner);
                    break;
                case 5:
                    System.out.println("Saliendo del programa. ¡Hasta luego!");
                    break;
                default:
                    System.out.println("Opción no válida. Por favor, seleccione una opción del 1 al 5.");
            }

        } while (opcion != 5);

        scanner.close();
    }

    private static void agregarNombre(ArrayList<String> listaNombres, Scanner scanner) {
        System.out.print("Ingrese el nombre a agregar: ");
        String nombre = scanner.next();
        listaNombres.add(nombre);
        System.out.println("Nombre agregado correctamente.");
    }

    private static void eliminarNombre(ArrayList<String> listaNombres, Scanner scanner) {
        if (listaNombres.isEmpty()) {
            System.out.println("La lista de nombres está vacía. No hay nombres para eliminar.");
        } else {
            System.out.print("Ingrese el nombre a eliminar: ");
            String nombre = scanner.next();
            if (listaNombres.remove(nombre)) {
                System.out.println("Nombre eliminado correctamente.");
            } else {
                System.out.println("El nombre no se encontró en la lista.");
            }
        }
    }

    private static void imprimirLista(ArrayList<String> listaNombres) {
        if (listaNombres.isEmpty()) {
            System.out.println("La lista de nombres está vacía.");
        } else {
            System.out.println("Lista de nombres:");
            for (String nombre : listaNombres) {
                System.out.println(nombre);
            }
        }
    }

    private static void buscarNombre(ArrayList<String> listaNombres, Scanner scanner) {
        if (listaNombres.isEmpty()) {
            System.out.println("La lista de nombres está vacía. No hay nombres para buscar.");
        } else {
            System.out.print("Ingrese el nombre a buscar: ");
            String nombre = scanner.next();
            if (listaNombres.contains(nombre)) {
                System.out.println("El nombre se encuentra en la lista.");
            } else {
                System.out.println("El nombre no se encuentra en la lista.");
            }
        }
    }
}


