package EJERCICIOS.EJERCICIO28;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        List<Persona> listaPersonas = new ArrayList<>();

        for (int i = 0; i < 5; i++) {
            System.out.println("Ingrese los datos de la persona " + (i + 1) + ":");

            Persona persona = new Persona();

            System.out.print("Nombre: ");
            persona.setNombre(scanner.next());

            System.out.print("Apellido: ");
            persona.setApellido(scanner.next());

            System.out.print("Género: ");
            persona.setGenero(scanner.next());

            System.out.print("Edad: ");
            persona.setEdad(scanner.nextInt());

            listaPersonas.add(persona);
        }

        retornarNombreGenero(listaPersonas);
        retornarPromedioEdades(listaPersonas);
        retornarPersonasMasculinas(listaPersonas);
        retornarPersonasFemeninas(listaPersonas);

        scanner.close();
    }

    private static void retornarNombreGenero(List<Persona> listaPersonas) {
        System.out.println("\nNombre, Apellido y Género de cada persona:");
        for (Persona persona : listaPersonas) {
            System.out.println(persona.getNombre() + " " + persona.getApellido() + " - " + persona.getGenero());
        }
    }

    private static void retornarPromedioEdades(List<Persona> listaPersonas) {
        int sumaEdades = 0;
        for (Persona persona : listaPersonas) {
            sumaEdades += persona.getEdad();
        }
        double promedioEdades = (double) sumaEdades / listaPersonas.size();
        System.out.println("\nPromedio de edades: " + promedioEdades);
    }

    private static void retornarPersonasMasculinas(List<Persona> listaPersonas) {
        int countMasculinos = 0;
        for (Persona persona : listaPersonas) {
            if ("masculino".equalsIgnoreCase(persona.getGenero())) {
                countMasculinos++;
            }
        }
        System.out.println("\nCantidad de personas de género masculino: " + countMasculinos);
    }

    private static void retornarPersonasFemeninas(List<Persona> listaPersonas) {
        int countFemeninos = 0;
        for (Persona persona : listaPersonas) {
            if ("femenino".equalsIgnoreCase(persona.getGenero())) {
                countFemeninos++;
            }
        }
        System.out.println("Cantidad de personas de género femenino: " + countFemeninos);
    }
}
