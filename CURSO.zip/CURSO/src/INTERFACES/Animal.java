package INTERFACES;
// Definición de la interfaz
interface Animal {
    void hacerSonido();
    void moverse();
}
