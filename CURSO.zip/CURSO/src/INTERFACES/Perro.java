package INTERFACES;

// Implementación de la interfaz en una clase
class Perro implements Animal {
    @Override
    public void hacerSonido() {
        System.out.println("El perro hace woof woof");
    }

    @Override
    public void moverse() {
        System.out.println("El perro se mueve corriendo");
    }
}