package INTERFACES;

// Clase principal que utiliza las implementaciones de la interfaz
public class Main {
    public static void main(String[] args) {
        Animal miPerro = new Perro();
        Animal miPajaro = new Pajaro();

        miPerro.hacerSonido();
        miPerro.moverse();

        miPajaro.hacerSonido();
        miPajaro.moverse();
    }
}
