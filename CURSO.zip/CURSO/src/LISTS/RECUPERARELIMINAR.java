package LISTS;


import java.util.ArrayList;
import java.util.List;

public class RECUPERARELIMINAR {
    public static void main(String[] args) {
        List list = new ArrayList<String>();
        list.add("hello");
        list.add("freeCodeCamp");
        list.remove(0);

        System.out.println(list.size());
        System.out.println(list.get(0));
    }
}

/* Para recuperar un elemento de la lista, puedes usar el método get y
proporcionar el índice del elemento que desea obtener.

Para eliminar un elemento de ArrayList, se utiliza el método remove.

También podemos llamar al método remove con un elemento para buscarlo y
eliminarlo. Ten en cuenta que solo elimina la primera aparición del elemento
si está presente.

Para eliminar todas las ocurrencias, podemos usar el método removeAll
de la misma manera.

Para obtener la longitud de una lista, o el número de elementos,
podemos usar el método size().

 */
