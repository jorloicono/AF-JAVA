package LISTS;

import java.util.ArrayList;
import java.util.List;

public class CREARLISTA {
    public static void main(String[] args) {
        ArrayList<Integer> list0 = new ArrayList<>();

        List list = new ArrayList<>(20);

    }
}
/*En los corchetes angulares (<>) especificamos el tipo de objetos que
vamos a almacenar.

Tenga en cuenta que el tipo entre paréntesis debe ser un tipo de objeto y
no un tipo primitivo. Por lo tanto, tenemos que usar envoltorios de objetos,
clase Integer en lugar de int, Double en lugar de double, y así sucesivamente.

Hay muchas formas de crear una ArrayList, la primera forma es creando el
objeto a partir de la clase ArrayList concreta, especificando ArrayList
en el lado izquierdo de la asignación.

También podemos especificar la capacidad inicial de la lista.

Esto es útil porque cada vez que la lista se llena e intenta agregar
otro elemento, la lista actual se copia en una nueva lista con el doble
de capacidad que la lista anterior. Todo esto sucede detrás de escena.

Esta operación hace que nuestra complejidad sea O(n), por lo que
queremos evitarla. La capacidad por defecto es 10, por lo que si sabes
que vas a almacenar más elementos, debes especificar la capacidad inicial.
 */